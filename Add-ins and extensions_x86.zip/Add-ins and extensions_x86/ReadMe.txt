============================================================
This directory contains installation files for Microsoft Identity Manager Add-ins and extensions.
============================================================

Files:
======

1. Add-ins and extensions.msi
This is the Add-ins and extensions installer file. Run it directly and fill in the necessary parameters throughout the installation.

2. Add-ins and extensions_Reference.bat
This reference file provides a template for the parameters needed during installation. To make multiple installations more efficient, fill in this template and then run this file, instead of using the .msi file.
	

Instructions for using the .bat file:
=====================================
1. Open the "_Reference.bat" file.
2. Change the parameters as needed.
3. Run the .bat file.

Notes:
======
1. When changing the Add-ins and extensions_Reference.bat file, use the relevant machine, domain, users, etc.
2. The bat file will remain open for 10 seconds after the installation completes to enable you to review the parameters you entered.
